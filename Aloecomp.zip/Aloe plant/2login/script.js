function goToPage(page) {
    window.location.href = page;
}
